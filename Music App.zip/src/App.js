import React, { useState, useEffect } from "react";

function App() {
  const [musicSuggestions, setMusicSuggestions] = useState([]);

  useEffect(() => {}, []);

  return (
    <div className="App">
      <h1>Sound Advice App</h1>
      <div>
        <h2>Our Top Picks</h2>
        <ul>
          {musicSuggestions.map((suggestion, index) => (
            <li key={index}>{suggestion}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
